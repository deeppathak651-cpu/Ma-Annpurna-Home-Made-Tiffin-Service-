# Kumaoni Potli — GitHub Pages Icon Ready

Upload ALL files/folders from this package to the same GitHub Pages folder:

- index.html
- manifest.json
- sw.js
- icons/icon-192.png
- icons/icon-512.png

Do not upload only index.html if you want the installable PWA icon.

After GitHub Pages is live:
1. Open the HTTPS GitHub Pages URL in Chrome.
2. Open the browser menu.
3. Choose "Install app" / "Add to Home screen".
4. The installed web app uses the Kumaoni Potli icon.

This does not change an already-built APK. It prepares the GitHub Pages web app/PWA.
