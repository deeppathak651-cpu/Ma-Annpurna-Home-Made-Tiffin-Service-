Kumaoni Potli GitHub Actions build

1. Create/open a GitHub repository.
2. Upload .github/workflows/build-apks.yml
3. Create input/ and upload:
   - admin-panel.apk
   - customer.apk
   - restaurant.apk
   - delivery.apk
   - admin-panel.html
4. GitHub -> Actions -> Build Kumaoni Potli APKs -> Run workflow.
5. Download the artifact named Kumaoni-Potli-Admin.

Important: the workflow repacks the existing Admin APK and signs it with a new test key. A previously installed APK signed with a different key may need to be uninstalled before installing the rebuilt APK.
